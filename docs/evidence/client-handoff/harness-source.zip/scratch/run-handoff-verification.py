from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
runtime = root.parent / 'runtime_tools'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
command = [
    'node', str(runtime / 'run-in-stack.mjs'), str(root / 'server'), 'env',
    'NODE_ENV=test', f'VANDAO_EXPECTED_BACKEND_COMMIT={head}',
    'VANDAO_PLAYWRIGHT_MODULE=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.js',
    f'VANDAO_CHROMIUM_MODULE={runtime}/node_modules/@sparticuz/chromium/build/index.js',
    f'PLAYWRIGHT_BROWSERS_PATH={runtime}/browser-cache',
    'node', '--import', 'tsx', '../scratch/run-final-smoke.mjs',
]
began = datetime.datetime.now(datetime.timezone.utc)
result = subprocess.run(command, cwd=root / 'server', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
out = root / 'docs/evidence/final-verification'
out.mkdir(parents=True, exist_ok=True)
log = out / 'client-handoff-command.txt'
log.write_bytes(result.stdout)
record = {
    'cwd': str(root / 'server'), 'command': command,
    'sourceCommit': head, 'startedAt': began.isoformat(),
    'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exitCode': result.returncode, 'outputFile': log.name,
    'outputBytes': len(result.stdout),
    'outputSha256': hashlib.sha256(result.stdout).hexdigest(),
    'recordOrigin': 'Direct subprocess result of the shared local test queue runner.',
}
(out / 'client-handoff-command-result.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exitCode': result.returncode, 'sourceCommit': head, 'outputBytes': len(result.stdout)}))
sys.exit(result.returncode)
