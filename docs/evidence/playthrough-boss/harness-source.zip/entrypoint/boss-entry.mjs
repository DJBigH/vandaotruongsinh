import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {serveFrozenClient} from '../../scripts/verification/frozen-preview.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
const frozen=JSON.parse(readFileSync(resolve(root,'scratch/browser-session/boss-frozen.json'),'utf8'));
const frontend=await serveFrozenClient(root,frozen,{backendUrl:'http://127.0.0.1:3001',port:5174});
process.env.VANDAO_TEST_URL='http://127.0.0.1:5174';
process.env.VANDAO_BUILD_MANIFEST=frozen.manifest;
try {await import('../../scripts/verification/play-session.mjs');} finally {await frontend.close();}
