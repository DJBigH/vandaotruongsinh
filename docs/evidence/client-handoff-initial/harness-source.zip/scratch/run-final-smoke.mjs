import assert from 'node:assert/strict';
import {mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {setTimeout as delay} from 'node:timers/promises';
import {freezeClientBuild,serveFrozenClient} from '../scripts/verification/frozen-preview.mjs';
import {assertLocalTestConfiguration,sourceStamp,writeJson} from '../scripts/verification/evidence-utils.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
process.env.NODE_ENV='test';
const base='http://127.0.0.1:5174',backendUrl='http://127.0.0.1:3001';
const out=resolve(process.env.VANDAO_EVIDENCE_DIR??`${root}/docs/evidence/client-handoff`);
mkdirSync(out,{recursive:true});
await assertLocalTestConfiguration(base);
const source=sourceStamp(root);
assert(!source.gameSourceDirty,'Commit product changes before this final smoke capture');
assert.equal(source.commit,process.env.VANDAO_EXPECTED_BACKEND_COMMIT,'Restart the main backend from the stated product commit before this capture');
let health=null;
for(let attempt=0;attempt<40;attempt++){
  try{const response=await fetch(`${backendUrl}/api/health`);if(response.ok()){health=await response.json();break;}}catch{}
  await delay(250);
}
assert(health,'Main source backend is not healthy');
writeJson(`${out}/backend-start.json`,{
  source,startedFromCommit:process.env.VANDAO_EXPECTED_BACKEND_COMMIT,healthy:true,
  capturedAt:new Date().toISOString(),health,
  note:'Controller restarted the main source backend at the stated commit before this run. This is an operation record plus health observation, not a server endpoint that attests its own source commit.'
});
const frozen=freezeClientBuild(root);
writeJson(`${out}/client-build.json`,frozen.stamp);
const frontend=await serveFrozenClient(root,frozen,{backendUrl,port:5174});
process.env.VANDAO_TEST_URL=base;
process.env.VANDAO_EVIDENCE_DIR=out;
try{
  await import('../scripts/verification/browser-smoke.mjs');
  if(!process.exitCode)await import('../scripts/verification/terminal-handover-browser.mjs');
}
finally{await frontend.close();}
