import {mkdirSync} from 'node:fs';
import {sourceStamp,writeJson} from '../../scripts/verification/evidence-utils.mjs';
const root='/workspace/scratch/c5685e889d73/vandaotruongsinh';
mkdirSync(process.env.VANDAO_EVIDENCE_DIR,{recursive:true});
const response=await fetch('http://127.0.0.1:3001/api/health');
if(!response.ok)throw new Error('Backend is not healthy');
writeJson(`${process.env.VANDAO_EVIDENCE_DIR}/backend-start.json`,{
 source:sourceStamp(root),startedFromCommit:'afa7fd25606db19b9b915cb915ba295cdecda00c',
 healthy:true,capturedAt:new Date().toISOString(),note:'Controller restarted the main source backend before this targeted UI check. Any later launcher-only commit does not change its game code.'
});
await import('../../scripts/verification/serve-and-play.mjs');
